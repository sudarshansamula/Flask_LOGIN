var admin_scr = {};
admin_scr.instanceInfoScr = function(){
	var inst_info = adminConfig.instance_info,
		instOpt = ['<option value="none" selected>Choose plan</option>'];
	 inst_info.map(function(v){
		if(v.id > 1)
			instOpt.push('<option value="'+v.id+'">'+v.plan_name+'</option>');
	});
	var html_str = '<div class="form-group" name="inst_info_div" style="margin-left:-60px;"> '+
					'<label for="name" class="col-sm-3 control-label" style="text-align:right">'+
						'Choose plan'+
					'</label>  '+
					'<div class="col-sm-9"> '+
						'<select class="form-control-static" name="instance_id" style="width:48%;min-height:25px;border-radius:none">'+instOpt.join()+'</select>'+
					'</div>' +
				'</div>';
	return html_str;
};
admin_scr.getUserTypeScr = function(configObj){
	//console.log(configObj)
	var user_info = configObj.user_info,
			user_type = adminConfig.user_type,
			roles_in_db = adminConfig.rolesInfo.roles_in_db,
			user_type_str = "",
			roles_in_db = adminConfig.rolesInfo.roles_in_db,
			roles_in_display = adminConfig.rolesInfo.roles_in_display,
			roles_db_to_dis = adminConfig.rolesInfo.roles_db_to_dis,
			isCreate = configObj.isCreate ;
			//console.log(configObj,adminCofig)
	if(user_type == roles_in_db["super_admin"] && (isCreate == true || (isCreate == false && user_info.instance_id == 1))){
		user_type_str = '<select class="form-control-static" name="user_type" style="width:48%;min-height:25px;border-radius:none">'+
							'<option value="'+roles_in_db["account_admin"]+'">'+roles_in_display["account_admin"]+'</option>'+
							'<option value="'+roles_in_db["reseller"]+'">'+roles_in_display["reseller"]+'</option>'+
						'</select>';
	}else{
		if(user_type == "reseller"){
			user_type_str = 	'<label>Account Admin</label>'+
							'<input type="hidden" name="user_type" value=acc_admin>';
		}else {
			user_type_str = 	'<label>'+roles_db_to_dis[user_info.user_type]+'</label>'+
							'<input type="hidden" name="user_type" value='+user_info.user_type+'>';
		}
		
	}
	user_type_str = '<div class="form-group" style="margin-left:-60px;margin-top:-10px;"> '+
		'<label for="name" class="col-sm-3 control-label" style="text-align:right">'+
			'User Type'+
		'</label>  '+
		'<div class="col-sm-9"> '+
			user_type_str+
		'</div>' +
	'</div>'
	return user_type_str;
}
admin_scr.getIdStr = function(user_info){
	var str = "";
	if(user_info){
		str = '<div class="col-sm-9"> '+
				'<label>'+user_info.user_id+'</label>'+
			'</div>';
		str = 	'<div class="form-group"> '+
					'<label for="name" class="col-sm-3 control-label" style="text-align: left">'+
						'User id '+
					'</label> '+str+
			'</div>';
		return str;
	}else{
		return "";
	}
	
};
admin_scr.getFeaturesStr = function(configObj){
	var isCreate = configObj.isCreate,
		//user_type = adminCofig.user_type,
		//roles_in_db = adminCofig.rolesInfo.roles_in_db,
		table_seq = configObj.features_config.table_fields_seq,
		table_info = configObj.features_config.table_info,
		display =  configObj.features_config.display;
	var str = "<div style='font-weight:bold;margin-left:10px;'>Features</div><br><div name='features' id='features' class='panel panel-default' style='border-bottom:none;'>";		
	for(var i of table_seq){
		if(display[i]["self"] == "Datasource")
			display[i]["self"] = "Datasets"

		str += '<ul class="align_ul_addept"><li><label for="option" class="labl_adjst">'+display[i]["self"]+'</label><ul class="row inner_ul_adjst">';
		for(var k in table_info[i]){
			var j = table_info[i][k];
			str +=  '<li class="col-md-4"><label style="font-weight:normal"><input type="checkbox" value='+j+' field_name='+i+' class="subOption measure_checkbox"><p class="measure_select_contents">'+(display[i][j] ? display[i][j] : j)+'</p></label></li>';
		}
		str += '</ul></li></ul>'; 
	}
	str += '</div>';
	return str;
};
admin_scr.getUserInfoStr = function(user_info){
	if(user_info == undefined)
		user_info = {};
	var str = "";
	if(user_info.user_id){
		/*str = 	'<div class="form-group"> '+
					'<label for="name" class="col-sm-3 control-label" style="text-align: left">'+
						'User id '+
					'</label> '+
					'<div class="col-sm-9"> '+
						'<label>'+user_info.user_id+'</label>'+
					'</div>'+
			'</div>';*/
	}
	str = str + '<div class="form-group" style="margin-left:-60px;"> '+
					'<label for="first_name" class="col-sm-3 control-label" style="text-align: right">'+
						'First Name'+
					'</label>'+
					'<div class="col-sm-9">'+
						'<input type="text" name="first_name" value="'+(user_info.first_name ? user_info.first_name : "")+'" placeholder="First Name" style="width:48%;height:30px">'+
					'</div>'+
			'</div>'+
			'<div class="form-group" style="margin-left:-60px;"> '+
					'<label for="last_name" class="col-sm-3 control-label" style="text-align: right">'+
						'Last Name'+
					'</label>'+
					'<div class="col-sm-9">'+
						'<input type="text" name="last_name"  value="'+(user_info.last_name ? user_info.last_name : "")+'" placeholder="Last Name" style="width:48%;height:30px">'+
					'</div>'+
			'</div>'+
			'<div class="form-group" style="margin-left:-60px;"> '+
					'<label for="mobile_no" class="col-sm-3 control-label" style="text-align: right">'+
						'Mobile No'+
					'</label>'+
					'<div class="col-sm-9">'+
						'<input type="text" name="mobile_no" value="'+(user_info.mobile ? user_info.mobile : "")+'" placeholder="Mobile No" style="width:48%;height:30px">'+
					'</div>'+
			'</div>'+
			'<div class="form-group" style="margin-left:-60px;"> '+
					'<label for="email" class="col-sm-3 control-label" style="text-align: right">'+
						'Email'+
					'</label>'+
					'<div class="col-sm-9">'+
						'<input type="text" name="email" value="'+(user_info.email ? user_info.email : "")+'" placeholder="Email" style="width:48%;height:30px">'+
					'</div>'+
			'</div>'+
			'<div class="form-group" name="password" style="margin-left:-60px;"> '+
					'<label for="password" class="col-sm-3 control-label" style="text-align: right">'+
						'Password'+
					'</label>'+
					'<div class="col-sm-9">'+
						'<input type="password" name="password" value="'+(user_info.password ? user_info.password : "")+'" placeholder="Password" style="width:48%;height:30px">'+
					'</div>'+
			'</div>'+
			'<div class="form-group" name="c_password" style="margin-left:-60px;"> '+
					'<label for="c_password" class="col-sm-3 control-label" style="text-align: right;margin-top:-10px;">'+
						'Confirm<br>Password'+
					'</label>'+
					'<div class="col-sm-9">'+
						'<input type="password" name="c_password" value="'+(user_info.password ? user_info.password : "")+'" placeholder="Confirm Password" style="width:48%;height:30px">'+
					'</div>'+
			'</div>';
	return str;
};
admin_scr.addOrEditProfile = function(configObj){
	var user_info = configObj.user_info,
		user_type = adminConfig.user_type,
		_this = this,
		roles_in_db = adminConfig.rolesInfo.roles_in_db,
		roles_in_display = adminConfig.rolesInfo.roles_in_display;
	var user_type_str = _this.getUserTypeScr(configObj),
		inst_info_str = _this.instanceInfoScr(),
		features_str = _this.getFeaturesStr(configObj),
		user_info_str = _this.getUserInfoStr(user_info),
		update_or_add = ((user_info) ? "Update" : "Add");

	var admin_active_status ='<div class="form-group" name="user_status_div" style="margin-left:-60px;"> '+
					'<label for="name" class="col-sm-3 control-label" style="text-align:right">'+
						'Active Type'+
					'</label>  '+
					'<div class="col-sm-9"> '+
						'<select class="form-control-static" name="user_active_type" style="width:48%;border-radius:none">'+
							'<option value="ACTIVE">Active</option>'+
							'<option value="INACTIVE">In Active</option>'+
						'</select>'+
					'</div>' +
				'</div>'

	var classAttr="fa fa-user fa-2x";
	var title = "Edit Profile";
		if(configObj.divId=="createProfileId"){
			classAttr = 'fa fa-user-plus fa-2x';
			title = "Create Profile";
		}

	var form_str = '<div class="modal fade" data-backdrop="static" data-keyboard="false" id='+configObj.divId+'>'+
				'<div class="modal-dialog">'+
					'<div class="modal-content">'+
						getModalHeader(classAttr,title)+	
						'<div class="modal-body customBody">'+
							'<form class="form-horizontal">'+	
								// '<div class="form-group">'+
								// 	'<i class="fa fa-user" aria-hidden="true"></i>'+
								// '</div>'+
								user_info_str+
								user_type_str+
								inst_info_str+
								admin_active_status+
								features_str+
								'</form>'+
								'</div>'+
								getModalFooter(update_or_add)+
					'</div>'+
				'</div>'+
			'</div>';
	return form_str;		
};
// admin_scr.addUserByAdmins = function(){
// 	var configObj = {};
// 		configObj.divId = "editProfileId",
// 		form_str = this.editProfileScr(configObj);
// 	return form_str;
// };
function getModalFooter(update_or_add){
	return '<div class="modal-footer">'+
							// '<button type="button" class="btn btn-default" data-dismiss="modal">close</button>'+
								'<button type="button"  value="'+update_or_add+'" name="sub_but" class="btn btn-primary" style="float:right">'+update_or_add+
								'</button>'+
						'</div>';
}

function getModalHeader(classAttr,title){
	return '<div class="modal-header">'+
	'<button type="button" class="close" title="Close" data-dismiss="modal">&times;</button>'+
	                        '<h4 class="head_font">'+title+'</h4>'+
							// '<label><span class="modal-title" style="font-size:18px;margin-right:5px">'+title+'</span><i class="'+classAttr+'" aria-hidden="true"></i><label>'+
						'</div>';
}
