"use strict";
function getXmlHttpObject() { 
	var objXMLHttp=null;
      if (window.XMLHttpRequest){
        objXMLHttp = new XMLHttpRequest();
      } else if (window.ActiveXObject) {
         objXMLHttp=new ActiveXObject("Microsoft.XMLHTTP");
       }if (objXMLHttp==null){ 
         alert ("Browser does not support HTTP Request");
      } 
      return objXMLHttp;
}
function getEle(name) {
    return document.getElementById(name);
}
function getEleVal(name) {
    return document.getElementById(name).value;
}
function setIHT(ele,val) {
	  getEle(ele).innerHTML=val;
}
function sendSyncReq(url)
{
   try{ 
	  var xmlHttpReq=getXmlHttpObject();
     if (xmlHttpReq==null) return;
	  xmlHttpReq.open("GET",url,false);
     xmlHttpReq.send('null');
     var resp=xmlHttpReq.responseText;
	  if(resp.indexOf('Your session is expired Please login again')!=-1){	
	   window.location.href="/php/session_expire.php";
	   return;
		}
		return resp;
	}
	catch(e)
	{
		alert(e);
	}
}

function sendSyncpostReq(url,data)
{
   try{ 
    var xmlHttpReq=getXmlHttpObject();
     if (xmlHttpReq==null) return;
    xmlHttpReq.open("POST",url,false);
    xmlHttpReq.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xmlHttpReq.send(data);
     var resp=xmlHttpReq.responseText;
    if(resp.indexOf('Your session is expired Please login again')!=-1){ 
     window.location.href="/php/session_expire.php";
     return;
    }
    return resp;
  }
  catch(e)
  {
    alert(e);
  }
}



function buttonstatuschange()
{
  document.getElementById('showall').value="Hide Inactive";
}
function sendAsyncReq(url,div,check) {
	var xmlHttpReq=getXmlHttpObject();                 
   if (xmlHttpReq==null) return;
   xmlHttpReq.onreadystatechange=function (){
        	 if ((xmlHttpReq.readyState==1) || (xmlHttpReq.readyState==2) || (xmlHttpReq.readyState==3)) {
			setIHT(div,"<DIV  style='color:#00C100;margin-top:4cm;margin-left:6cm;'>&nbsp;&nbsp;&nbsp;<img src='/images/progressbar.gif'></img><br>Loading... </DIV>"); 
          	 } else {
            	var resp=xmlHttpReq.responseText;
				if (resp.indexOf('Your session is expired Please login again')!=-1){	
	   			window.location.href="/php/session_expire.php";
	   			return;
	 		}else {
				setIHT(div,resp);
				if((check=='list')&&(getEleVal('statuscheck')==1))
                buttonstatuschange();
		     	}	
	      } 
   };   
   xmlHttpReq.open("GET",url,true);
   xmlHttpReq.send('null');
}



function enable(ele) {
    getEle(ele).disabled=false;
	}
function disable(ele) {
   getEle(ele).disabled=true;
   getEle(ele).value='';
}
function setVal(ele,val) {
  getEle(ele).value=val;
}
function getVal(ele) {
  return document.getElementById(ele).value;
}
function dLoadScript(url)
{
   if (document.getElementById(url)) return;
   var e = document.createElement("script");
   e.src = url;
   e.id=url;
   e.type="text/javascript";
   document.getElementsByTagName("head")[0].appendChild(e);
}

function enableIsd(isd)
{
getEle('txtIsd').value=isd;
getEle('txtCustId').value='';
getEle('txtIsd').disabled=false;
getEle('newCust').innerHTML='';

}

function disableIsd(isd)
{
getEle('txtIsd').value=isd;
getEle('txtCustId').value='';
getEle('txtIsd').disabled=true;
getEle('newCust').innerHTML='';
}
